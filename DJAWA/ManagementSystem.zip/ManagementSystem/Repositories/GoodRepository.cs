﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SQLite;
using System.Threading.Tasks;
using ManagementSystem.Models;
using ManagementSystem.Utils;

namespace ManagementSystem.Repositories
{
    public class GoodRepository : IGoodRepository
    {
        private readonly DatabaseContext _context;

        public GoodRepository()
        {
            _context = DatabaseContext.Instance;
        }

        public async Task<List<Good>> GetAllAsync()
        {
            var goods = new List<Good>();

            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                var query = "SELECT * FROM Goods ORDER BY Name";

                using (var command = new SQLiteCommand(query, connection))
                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        goods.Add(MapToGood((SQLiteDataReader)reader));
                    }
                }
            }

            return goods;
        }

        public async Task<Good> GetByIdAsync(int id)
        {
            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                var query = "SELECT * FROM Goods WHERE Id = @id";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return MapToGood((SQLiteDataReader)reader);
                        }
                    }
                }
            }

            return null;
        }

        public async Task<List<Good>> SearchByNameAsync(string name)
        {
            var goods = new List<Good>();
            var sanitizedName = SecurityHelper.SanitizeInput(name);

            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                var query = "SELECT * FROM Goods WHERE Name LIKE @name ORDER BY Name";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", $"%{sanitizedName}%");

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            goods.Add(MapToGood((SQLiteDataReader)reader));
                        }
                    }
                }
            }

            return goods;
        }

        public async Task<int> AddAsync(Good good)
        {
            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var query = @"
                            INSERT INTO Goods (Name, Description, Quantity, Price, CreatedAt, UpdatedAt)
                            VALUES (@name, @description, @quantity, @price, @createdAt, @updatedAt);
                            SELECT last_insert_rowid();";

                        using (var command = new SQLiteCommand(query, connection, transaction))
                        {
                            AddParameters(command, good);
                            var result = await command.ExecuteScalarAsync();
                            var newId = Convert.ToInt32(result);

                            transaction.Commit();
                            return newId;
                        }
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public async Task<bool> UpdateAsync(Good good)
        {
            good.UpdateTimestamp();

            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var query = @"
                            UPDATE Goods 
                            SET Name = @name, Description = @description, 
                                Quantity = @quantity, Price = @price, UpdatedAt = @updatedAt
                            WHERE Id = @id";

                        using (var command = new SQLiteCommand(query, connection, transaction))
                        {
                            AddParameters(command, good);
                            command.Parameters.AddWithValue("@id", good.Id);

                            var affected = await command.ExecuteNonQueryAsync();
                            transaction.Commit();

                            return affected > 0;
                        }
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        public async Task<bool> DeleteAsync(int id)
        {
            using (var connection = _context.GetConnection())
            {
                await connection.OpenAsync();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var query = "DELETE FROM Goods WHERE Id = @id";

                        using (var command = new SQLiteCommand(query, connection, transaction))
                        {
                            command.Parameters.AddWithValue("@id", id);
                            var affected = await command.ExecuteNonQueryAsync();

                            transaction.Commit();
                            return affected > 0;
                        }
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        // FIXED MapToGood method with safe type conversions
        private Good MapToGood(SQLiteDataReader reader)
        {
            return new Good
            {
                Id = GetSafeInt(reader, "Id"),
                Name = GetSafeString(reader, "Name"),
                Description = GetSafeString(reader, "Description"),
                Quantity = GetSafeInt(reader, "Quantity"),
                Price = GetSafeDecimal(reader, "Price"),
                CreatedAt = GetSafeDateTime(reader, "CreatedAt"),
                UpdatedAt = GetSafeDateTime(reader, "UpdatedAt")
            };
        }

        // Helper methods for safe data conversion
        private int GetSafeInt(SQLiteDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return 0;

                var value = reader[columnName];
                return Convert.ToInt32(value);
            }
            catch
            {
                return 0;
            }
        }

        private string GetSafeString(SQLiteDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return string.Empty;

                return reader[columnName]?.ToString() ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        private decimal GetSafeDecimal(SQLiteDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return 0m;

                var value = reader[columnName];
                return Convert.ToDecimal(value);
            }
            catch
            {
                return 0m;
            }
        }

        private DateTime GetSafeDateTime(SQLiteDataReader reader, string columnName)
        {
            try
            {
                var ordinal = reader.GetOrdinal(columnName);
                if (reader.IsDBNull(ordinal))
                    return DateTime.Now;

                var value = reader[columnName];
                if (DateTime.TryParse(value.ToString(), out DateTime result))
                    return result;

                return DateTime.Now;
            }
            catch
            {
                return DateTime.Now;
            }
        }

        // FIXED AddParameters method
        private void AddParameters(SQLiteCommand command, Good good)
        {
            // Clear existing parameters first
            command.Parameters.Clear();

            // Add parameters with proper null handling
            command.Parameters.AddWithValue("@name",
                SecurityHelper.SanitizeInput(good.Name ?? string.Empty));

            command.Parameters.AddWithValue("@description",
                SecurityHelper.SanitizeInput(good.Description ?? string.Empty));

            command.Parameters.AddWithValue("@quantity", good.Quantity);
            command.Parameters.AddWithValue("@price", good.Price);
            command.Parameters.AddWithValue("@createdAt", good.CreatedAt);
            command.Parameters.AddWithValue("@updatedAt", good.UpdatedAt);
        }
    }
}