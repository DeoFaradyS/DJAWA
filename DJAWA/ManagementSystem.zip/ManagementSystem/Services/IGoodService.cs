﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ManagementSystem.Models;

namespace ManagementSystem.Services
{
    public interface IGoodService
    {
        Task<List<Good>> GetAllGoodsAsync();
        Task<Good> GetGoodByIdAsync(int id);
        Task<List<Good>> SearchGoodsByNameAsync(string name);
        Task<int> CreateGoodAsync(Good good);
        Task<bool> UpdateGoodAsync(Good good);
        Task<bool> DeleteGoodAsync(int id);
        bool ValidateGood(Good good, out List<string> errors);
    }
}