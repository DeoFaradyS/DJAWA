﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ManagementSystem.Models;
using ManagementSystem.Repositories;
using ManagementSystem.Utils;

namespace ManagementSystem.Services
{
    public class GoodService : IGoodService
    {
        private readonly IGoodRepository _repository;

        public GoodService(IGoodRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<Good>> GetAllGoodsAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Good> GetGoodByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public async Task<List<Good>> SearchGoodsByNameAsync(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return await GetAllGoodsAsync();

            return await _repository.SearchByNameAsync(name);
        }

        public async Task<int> CreateGoodAsync(Good good)
        {
            if (!ValidateGood(good, out var errors))
                throw new ValidationException($"Validasi gagal: {string.Join(", ", errors)}");

            return await _repository.AddAsync(good);
        }

        public async Task<bool> UpdateGoodAsync(Good good)
        {
            if (!ValidateGood(good, out var errors))
                throw new ValidationException($"Validasi gagal: {string.Join(", ", errors)}");

            return await _repository.UpdateAsync(good);
        }

        public async Task<bool> DeleteGoodAsync(int id)
        {
            var existingGood = await _repository.GetByIdAsync(id);
            if (existingGood == null)
                return false;

            return await _repository.DeleteAsync(id);
        }

        public bool ValidateGood(Good good, out List<string> errors)
        {
            return ValidationHelper.ValidateGood(good, out errors);
        }
    }

    public class ValidationException : System.Exception
    {
        public ValidationException(string message) : base(message) { }
    }
}