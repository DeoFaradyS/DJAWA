﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ManagementSystem.Models;
using ManagementSystem.Services;
using ManagementSystem.Repositories;

namespace ManagementSystem.Views
{
    public partial class MainForm : Form
    {
        private readonly IGoodService _goodService;
        private List<Good> _currentGoods;
        private TextBox _searchTextBox;
        private DataGridView _dataGridView;

        public MainForm()
        {
            InitializeComponent();
            _goodService = new GoodService(new GoodRepository());
            _currentGoods = new List<Good>();

            CustomizeForm();
            SetupPlaceholderText();
            LoadDataAsync();
        }

        private void InitializeComponent()
        {
            // Form setup
            this.Text = "Sistem Manajemen Barang";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 244, 248);
            this.MinimumSize = new Size(800, 600);

            // Header Panel
            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 80,
                BackColor = Color.FromArgb(59, 130, 246),
                Padding = new Padding(20, 10, 20, 10)
            };

            var titleLabel = new Label
            {
                Text = "MANAJEMEN BARANG",
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 25)
            };

            // Search Panel
            var searchPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.White,
                Padding = new Padding(20, 10, 20, 10)
            };

            _searchTextBox = new TextBox
            {
                Name = "searchTextBox",
                Font = new Font("Segoe UI", 10),
                Location = new Point(20, 18),
                Size = new Size(300, 25),
                BorderStyle = BorderStyle.FixedSingle,
                ForeColor = Color.Gray
            };

            var searchButton = new Button
            {
                Name = "searchButton",
                Text = "🔍 Cari",
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Location = new Point(330, 16),
                Size = new Size(80, 29),
                BackColor = Color.FromArgb(34, 197, 94),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            searchButton.FlatAppearance.BorderSize = 0;

            var clearButton = new Button
            {
                Name = "clearButton",
                Text = "✕ Clear",
                Font = new Font("Segoe UI", 9),
                Location = new Point(420, 16),
                Size = new Size(70, 29),
                BackColor = Color.FromArgb(107, 114, 128),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            clearButton.FlatAppearance.BorderSize = 0;

            // Action Panel
            var actionPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(249, 250, 251),
                Padding = new Padding(20, 10, 20, 10)
            };

            var addButton = new Button
            {
                Name = "addButton",
                Text = "➕ Tambah Barang",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(20, 15),
                Size = new Size(140, 35),
                BackColor = Color.FromArgb(59, 130, 246),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            addButton.FlatAppearance.BorderSize = 0;

            var refreshButton = new Button
            {
                Name = "refreshButton",
                Text = "🔄 Refresh",
                Font = new Font("Segoe UI", 10),
                Location = new Point(170, 15),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(107, 114, 128),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            refreshButton.FlatAppearance.BorderSize = 0;

            // DataGridView
            _dataGridView = new DataGridView
            {
                Name = "dataGridView",
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                Font = new Font("Segoe UI", 9),
                GridColor = Color.FromArgb(229, 231, 235),
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(248, 250, 252)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    SelectionBackColor = Color.FromArgb(59, 130, 246),
                    SelectionForeColor = Color.White,
                    Padding = new Padding(5)
                },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(243, 244, 246),
                    ForeColor = Color.FromArgb(55, 65, 81),
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    Padding = new Padding(5)
                }
            };

            // Setup DataGridView columns
            _dataGridView.Columns.Add("Id", "ID");
            _dataGridView.Columns.Add("Name", "Nama Barang");
            _dataGridView.Columns.Add("Description", "Deskripsi");
            _dataGridView.Columns.Add("Quantity", "Jumlah");
            _dataGridView.Columns.Add("Price", "Harga");
            _dataGridView.Columns.Add("CreatedAt", "Dibuat");

            _dataGridView.Columns["Id"].Visible = false;
            _dataGridView.Columns["Name"].Width = 200;
            _dataGridView.Columns["Description"].Width = 250;
            _dataGridView.Columns["Quantity"].Width = 80;
            _dataGridView.Columns["Price"].Width = 120;
            _dataGridView.Columns["CreatedAt"].Width = 120;

            // Set column alignment
            _dataGridView.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            _dataGridView.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            _dataGridView.Columns["CreatedAt"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Add controls to panels
            headerPanel.Controls.Add(titleLabel);
            searchPanel.Controls.AddRange(new Control[] { _searchTextBox, searchButton, clearButton });
            actionPanel.Controls.AddRange(new Control[] { addButton, refreshButton });

            // Add panels to form
            this.Controls.Add(_dataGridView);
            this.Controls.Add(actionPanel);
            this.Controls.Add(searchPanel);
            this.Controls.Add(headerPanel);

            // Event handlers
            searchButton.Click += SearchButton_Click;
            clearButton.Click += ClearButton_Click;
            addButton.Click += AddButton_Click;
            refreshButton.Click += RefreshButton_Click;
            _dataGridView.CellDoubleClick += DataGridView_CellDoubleClick;
            _dataGridView.KeyDown += DataGridView_KeyDown;
            _searchTextBox.KeyDown += SearchTextBox_KeyDown;
        }

        private void SetupPlaceholderText()
        {
            // Implement placeholder text functionality
            string placeholderText = "Cari barang berdasarkan nama...";
            _searchTextBox.Text = placeholderText;
            _searchTextBox.ForeColor = Color.Gray;

            _searchTextBox.Enter += (sender, e) =>
            {
                if (_searchTextBox.Text == placeholderText)
                {
                    _searchTextBox.Text = "";
                    _searchTextBox.ForeColor = Color.Black;
                }
            };

            _searchTextBox.Leave += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(_searchTextBox.Text))
                {
                    _searchTextBox.Text = placeholderText;
                    _searchTextBox.ForeColor = Color.Gray;
                }
            };
        }

        private void CustomizeForm()
        {
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.Icon = SystemIcons.Application;
        }

        private async void LoadDataAsync()
        {
            try
            {
                // Show loading indicator
                this.Cursor = Cursors.WaitCursor;
                _currentGoods = await _goodService.GetAllGoodsAsync();
                PopulateDataGridView(_currentGoods);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void PopulateDataGridView(List<Good> goods)
        {
            _dataGridView.Rows.Clear();

            foreach (var good in goods)
            {
                _dataGridView.Rows.Add(
                    good.Id,
                    good.Name,
                    good.Description,
                    good.Quantity,
                    good.Price.ToString("C"),
                    good.CreatedAt.ToString("dd/MM/yyyy")
                );
            }

            // Update status
            this.Text = $"Sistem Manajemen Barang - {goods.Count} barang";
        }

        private async void SearchButton_Click(object sender, EventArgs e)
        {
            await PerformSearch();
        }

        private void SearchTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                PerformSearch();
                e.Handled = true;
            }
        }

        private async Task PerformSearch()
        {
            string searchTerm = _searchTextBox.Text.Trim();

            // Don't search if it's placeholder text
            if (searchTerm == "Cari barang berdasarkan nama..." || string.IsNullOrWhiteSpace(searchTerm))
            {
                PopulateDataGridView(_currentGoods);
                return;
            }

            try
            {
                this.Cursor = Cursors.WaitCursor;
                var results = await _goodService.SearchGoodsByNameAsync(searchTerm);
                PopulateDataGridView(results);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            _searchTextBox.Text = "Cari barang berdasarkan nama...";
            _searchTextBox.ForeColor = Color.Gray;
            PopulateDataGridView(_currentGoods);
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var addForm = new AddEditGoodForm();
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadDataAsync();
            }
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            LoadDataAsync();
        }

        private void DataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                ShowGoodDetail(e.RowIndex);
            }
        }

        private void DataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            var dataGridView = sender as DataGridView;

            if (e.KeyCode == Keys.Enter && dataGridView.SelectedRows.Count > 0)
            {
                ShowGoodDetail(dataGridView.SelectedRows[0].Index);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Delete && dataGridView.SelectedRows.Count > 0)
            {
                DeleteSelectedGood(dataGridView.SelectedRows[0].Index);
                e.Handled = true;
            }
        }

        private void ShowGoodDetail(int rowIndex)
        {
            var goodId = Convert.ToInt32(_dataGridView.Rows[rowIndex].Cells["Id"].Value);
            var good = _currentGoods.FirstOrDefault(g => g.Id == goodId);

            if (good != null)
            {
                var detailForm = new GoodDetailForm(good);
                if (detailForm.ShowDialog() == DialogResult.OK)
                {
                    LoadDataAsync();
                }
            }
        }

        private async void DeleteSelectedGood(int rowIndex)
        {
            var goodId = Convert.ToInt32(_dataGridView.Rows[rowIndex].Cells["Id"].Value);
            var goodName = _dataGridView.Rows[rowIndex].Cells["Name"].Value.ToString();

            var result = MessageBox.Show($"Apakah Anda yakin ingin menghapus '{goodName}'?",
                "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;
                    await _goodService.DeleteGoodAsync(goodId);
                    LoadDataAsync();
                    MessageBox.Show("Barang berhasil dihapus!", "Sukses",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting good: {ex.Message}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            var result = MessageBox.Show("Apakah Anda yakin ingin keluar?", "Konfirmasi",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }

            base.OnFormClosing(e);
        }
    }
}