﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ManagementSystem.Models;
using ManagementSystem.Services;
using ManagementSystem.Repositories;

namespace ManagementSystem.Views
{
    public partial class AddEditGoodForm : Form
    {
        private readonly IGoodService _goodService;
        private Good _good;
        private bool _isEditMode;

        public AddEditGoodForm(Good good = null)
        {
            _goodService = new GoodService(new GoodRepository());
            _good = good ?? new Good();
            _isEditMode = good != null;

            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            // Form setup
            this.Text = _isEditMode ? "Edit Barang" : "Tambah Barang Baru";
            this.Size = new Size(500, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(249, 250, 251);

            // Header Panel
            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(59, 130, 246),
                Padding = new Padding(20, 10, 20, 10)
            };

            var titleLabel = new Label
            {
                Text = _isEditMode ? "EDIT BARANG" : "TAMBAH BARANG BARU",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 18)
            };

            // Main Panel
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(30, 20, 30, 20),
                BackColor = Color.White
            };

            // Name
            var nameLabel = new Label
            {
                Text = "Nama Barang *",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(0, 20),
                Size = new Size(120, 20),
                ForeColor = Color.FromArgb(55, 65, 81)
            };

            var nameTextBox = new TextBox
            {
                Name = "nameTextBox",
                Font = new Font("Segoe UI", 10),
                Location = new Point(0, 45),
                Size = new Size(410, 25),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Description
            var descLabel = new Label
            {
                Text = "Deskripsi",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(0, 85),
                Size = new Size(120, 20),
                ForeColor = Color.FromArgb(55, 65, 81)
            };

            var descTextBox = new TextBox
            {
                Name = "descTextBox",
                Font = new Font("Segoe UI", 10),
                Location = new Point(0, 110),
                Size = new Size(410, 80),
                BorderStyle = BorderStyle.FixedSingle,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };

            // Quantity
            var quantityLabel = new Label
            {
                Text = "Jumlah *",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(0, 210),
                Size = new Size(120, 20),
                ForeColor = Color.FromArgb(55, 65, 81)
            };

            var quantityNumeric = new NumericUpDown
            {
                Name = "quantityNumeric",
                Font = new Font("Segoe UI", 10),
                Location = new Point(0, 235),
                Size = new Size(200, 25),
                Minimum = 0,
                Maximum = 999999,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Price
            var priceLabel = new Label
            {
                Text = "Harga *",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(210, 210),
                Size = new Size(120, 20),
                ForeColor = Color.FromArgb(55, 65, 81)
            };

            var priceNumeric = new NumericUpDown
            {
                Name = "priceNumeric",
                Font = new Font("Segoe UI", 10),
                Location = new Point(210, 235),
                Size = new Size(200, 25),
                Minimum = 0.01m,
                Maximum = 999999999.99m,
                DecimalPlaces = 2,
                ThousandsSeparator = true,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Button Panel
            var buttonPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 70,
                BackColor = Color.FromArgb(249, 250, 251),
                Padding = new Padding(30, 15, 30, 15)
            };

            var saveButton = new Button
            {
                Name = "saveButton",
                Text = _isEditMode ? "💾 Update" : "💾 Simpan",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Size = new Size(100, 35),
                Location = new Point(210, 15),
                BackColor = Color.FromArgb(34, 197, 94),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            var cancelButton = new Button
            {
                Name = "cancelButton",
                Text = "✕ Batal",
                Font = new Font("Segoe UI", 10),
                Size = new Size(100, 35),
                Location = new Point(320, 15),
                BackColor = Color.FromArgb(107, 114, 128),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            // Add controls
            headerPanel.Controls.Add(titleLabel);
            mainPanel.Controls.AddRange(new Control[] {
                nameLabel, nameTextBox, descLabel, descTextBox,
                quantityLabel, quantityNumeric, priceLabel, priceNumeric
            });
            buttonPanel.Controls.AddRange(new Control[] { saveButton, cancelButton });

            this.Controls.Add(mainPanel);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(headerPanel);

            // Event handlers
            saveButton.Click += SaveButton_Click;
            cancelButton.Click += CancelButton_Click;

            // Set tab order
            nameTextBox.TabIndex = 0;
            descTextBox.TabIndex = 1;
            quantityNumeric.TabIndex = 2;
            priceNumeric.TabIndex = 3;
            saveButton.TabIndex = 4;
            cancelButton.TabIndex = 5;
        }

        private void LoadData()
        {
            if (_isEditMode && _good != null)
            {
                var nameTextBox = this.Controls.Find("nameTextBox", true)[0] as TextBox;
                var descTextBox = this.Controls.Find("descTextBox", true)[0] as TextBox;
                var quantityNumeric = this.Controls.Find("quantityNumeric", true)[0] as NumericUpDown;
                var priceNumeric = this.Controls.Find("priceNumeric", true)[0] as NumericUpDown;

                nameTextBox.Text = _good.Name;
                descTextBox.Text = _good.Description;
                quantityNumeric.Value = _good.Quantity;
                priceNumeric.Value = _good.Price;
            }
        }

        private async void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                var nameTextBox = this.Controls.Find("nameTextBox", true)[0] as TextBox;
                var descTextBox = this.Controls.Find("descTextBox", true)[0] as TextBox;
                var quantityNumeric = this.Controls.Find("quantityNumeric", true)[0] as NumericUpDown;
                var priceNumeric = this.Controls.Find("priceNumeric", true)[0] as NumericUpDown;

                _good.Name = nameTextBox.Text.Trim();
                _good.Description = descTextBox.Text.Trim();
                _good.Quantity = (int)quantityNumeric.Value;
                _good.Price = priceNumeric.Value;

                if (_isEditMode)
                {
                    await _goodService.UpdateGoodAsync(_good);
                    MessageBox.Show("Barang berhasil diupdate!", "Sukses",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    await _goodService.CreateGoodAsync(_good);
                    MessageBox.Show("Barang berhasil ditambahkan!", "Sukses",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}