﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ManagementSystem.Models;

namespace ManagementSystem.Views
{
    public partial class GoodDetailForm : Form
    {
        private readonly Good _good;

        public GoodDetailForm(Good good)
        {
            _good = good;
            InitializeComponent();
            LoadData();
        }

        private void InitializeComponent()
        {
            // Form setup
            this.Text = "Detail Barang";
            this.Size = new Size(600, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(249, 250, 251);

            // Header Panel
            var headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 80,
                BackColor = Color.FromArgb(59, 130, 246),
                Padding = new Padding(30, 15, 30, 15)
            };

            var titleLabel = new Label
            {
                Text = "DETAIL BARANG",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(30, 15)
            };

            var subtitleLabel = new Label
            {
                Name = "subtitleLabel",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.FromArgb(191, 219, 254),
                AutoSize = true,
                Location = new Point(30, 45)
            };

            // Main Panel
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(30, 30, 30, 30),
                BackColor = Color.White,
                AutoScroll = true
            };

            // Details Panel
            var detailsPanel = new Panel
            {
                Size = new Size(500, 300),
                Location = new Point(0, 0),
                BackColor = Color.White
            };

            // Create detail labels
            var nameLabel = CreateDetailLabel("Nama Barang:", 0);
            var nameValue = CreateDetailValue("nameValue", 30);

            var descLabel = CreateDetailLabel("Deskripsi:", 70);
            var descValue = CreateDetailValue("descValue", 100, multiline: true);

            var quantityLabel = CreateDetailLabel("Jumlah:", 170);
            var quantityValue = CreateDetailValue("quantityValue", 200);

            var priceLabel = CreateDetailLabel("Harga:", 230);
            var priceValue = CreateDetailValue("priceValue", 260);

            var createdLabel = CreateDetailLabel("Dibuat:", 290);
            var createdValue = CreateDetailValue("createdValue", 320);

            var updatedLabel = CreateDetailLabel("Diupdate:", 350);
            var updatedValue = CreateDetailValue("updatedValue", 380);

            // Button Panel
            var buttonPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 80,
                BackColor = Color.FromArgb(249, 250, 251),
                Padding = new Padding(30, 20, 30, 20)
            };

            var editButton = new Button
            {
                Text = "✏ Edit",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Size = new Size(100, 35),
                Location = new Point(270, 20),
                BackColor = Color.FromArgb(59, 130, 246),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            var closeButton = new Button
            {
                Text = "✕ Tutup",
                Font = new Font("Segoe UI", 10),
                Size = new Size(100, 35),
                Location = new Point(380, 20),
                BackColor = Color.FromArgb(107, 114, 128),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            // Add controls
            headerPanel.Controls.AddRange(new Control[] { titleLabel, subtitleLabel });
            detailsPanel.Controls.AddRange(new Control[] {
                nameLabel, nameValue, descLabel, descValue,
                quantityLabel, quantityValue, priceLabel, priceValue,
                createdLabel, createdValue, updatedLabel, updatedValue
            });
            mainPanel.Controls.Add(detailsPanel);
            buttonPanel.Controls.AddRange(new Control[] { editButton, closeButton });

            this.Controls.Add(mainPanel);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(headerPanel);

            // Event handlers
            editButton.Click += EditButton_Click;
            closeButton.Click += CloseButton_Click;
        }

        private Label CreateDetailLabel(string text, int y)
        {
            return new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 65, 81),
                Location = new Point(0, y),
                Size = new Size(150, 25),
                AutoSize = false
            };
        }

        private Label CreateDetailValue(string name, int y, bool multiline = false)
        {
            return new Label
            {
                Name = name,
                Font = new Font("Segoe UI", 11),
                ForeColor = Color.FromArgb(75, 85, 99),
                Location = new Point(150, y),
                Size = new Size(350, multiline ? 60 : 25),
                AutoSize = false,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.FromArgb(249, 250, 251),
                Padding = new Padding(8, 4, 8, 4)
            };
        }

        private void LoadData()
        {
            var subtitleLabel = this.Controls.Find("subtitleLabel", true)[0] as Label;
            subtitleLabel.Text = $"ID: {_good.Id}";

            var nameValue = this.Controls.Find("nameValue", true)[0] as Label;
            nameValue.Text = _good.Name;

            var descValue = this.Controls.Find("descValue", true)[0] as Label;
            descValue.Text = string.IsNullOrEmpty(_good.Description) ? "-" : _good.Description;

            var quantityValue = this.Controls.Find("quantityValue", true)[0] as Label;
            quantityValue.Text = _good.Quantity.ToString() + " unit";

            var priceValue = this.Controls.Find("priceValue", true)[0] as Label;
            priceValue.Text = _good.Price.ToString("C");

            var createdValue = this.Controls.Find("createdValue", true)[0] as Label;
            createdValue.Text = _good.CreatedAt.ToString("dddd, dd MMMM yyyy HH:mm");

            var updatedValue = this.Controls.Find("updatedValue", true)[0] as Label;
            updatedValue.Text = _good.UpdatedAt.ToString("dddd, dd MMMM yyyy HH:mm");
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            var editForm = new AddEditGoodForm(_good);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}