﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ManagementSystem.Models
{
    public class Good
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nama barang wajib diisi")]
        [StringLength(100, ErrorMessage = "Nama maksimal 100 karakter")]
        public string Name { get; set; }

        [StringLength(500, ErrorMessage = "Deskripsi maksimal 500 karakter")]
        public string Description { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Jumlah harus positif")]
        public int Quantity { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Harga harus lebih dari 0")]
        public decimal Price { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public Good()
        {
            CreatedAt = DateTime.Now;
            UpdatedAt = DateTime.Now;
        }

        public void UpdateTimestamp()
        {
            UpdatedAt = DateTime.Now;
        }
    }
}